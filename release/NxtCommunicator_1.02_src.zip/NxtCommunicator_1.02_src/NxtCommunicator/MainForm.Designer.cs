﻿namespace NxtCommunicator
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.textBoxVal1 = new System.Windows.Forms.TextBox();
            this.textBoxVal2 = new System.Windows.Forms.TextBox();
            this.textBoxVal3 = new System.Windows.Forms.TextBox();
            this.textBoxVal4 = new System.Windows.Forms.TextBox();
            this.textBoxVal5 = new System.Windows.Forms.TextBox();
            this.textBoxVal6 = new System.Windows.Forms.TextBox();
            this.textBoxVal7 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxPort = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.val1SendButton = new System.Windows.Forms.Button();
            this.buttonLogClear = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.b = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.d = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.e = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.f = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.h = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.i = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.j = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.k = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.l = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chart0 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.csvOutputButton = new System.Windows.Forms.Button();
            this.csvInportButton = new System.Windows.Forms.Button();
            this.val2SendButton = new System.Windows.Forms.Button();
            this.val3SendButton = new System.Windows.Forms.Button();
            this.val4SendButton = new System.Windows.Forms.Button();
            this.val5SendButton = new System.Windows.Forms.Button();
            this.val6SendButton = new System.Windows.Forms.Button();
            this.val7SendButton = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBoxChartingTarget0 = new System.Windows.Forms.ComboBox();
            this.comboBoxChartingTarget1 = new System.Windows.Forms.ComboBox();
            this.comboBoxChartingTarget2 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxMaxLine = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(194, 12);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(57, 23);
            this.buttonConnect.TabIndex = 2;
            this.buttonConnect.Text = "接続";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // textBoxVal1
            // 
            this.textBoxVal1.Location = new System.Drawing.Point(50, 24);
            this.textBoxVal1.Name = "textBoxVal1";
            this.textBoxVal1.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal1.TabIndex = 11;
            // 
            // textBoxVal2
            // 
            this.textBoxVal2.Location = new System.Drawing.Point(50, 49);
            this.textBoxVal2.Name = "textBoxVal2";
            this.textBoxVal2.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal2.TabIndex = 13;
            // 
            // textBoxVal3
            // 
            this.textBoxVal3.Location = new System.Drawing.Point(50, 75);
            this.textBoxVal3.Name = "textBoxVal3";
            this.textBoxVal3.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal3.TabIndex = 15;
            // 
            // textBoxVal4
            // 
            this.textBoxVal4.Location = new System.Drawing.Point(50, 99);
            this.textBoxVal4.Name = "textBoxVal4";
            this.textBoxVal4.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal4.TabIndex = 17;
            // 
            // textBoxVal5
            // 
            this.textBoxVal5.Location = new System.Drawing.Point(50, 124);
            this.textBoxVal5.Name = "textBoxVal5";
            this.textBoxVal5.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal5.TabIndex = 19;
            // 
            // textBoxVal6
            // 
            this.textBoxVal6.Location = new System.Drawing.Point(50, 149);
            this.textBoxVal6.Name = "textBoxVal6";
            this.textBoxVal6.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal6.TabIndex = 21;
            // 
            // textBoxVal7
            // 
            this.textBoxVal7.Location = new System.Drawing.Point(50, 174);
            this.textBoxVal7.Name = "textBoxVal7";
            this.textBoxVal7.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal7.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "値１";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "値２";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "値３";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "値４";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "値５";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "値６";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 177);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "値７";
            // 
            // comboBoxPort
            // 
            this.comboBoxPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPort.FormattingEnabled = true;
            this.comboBoxPort.Location = new System.Drawing.Point(57, 14);
            this.comboBoxPort.Name = "comboBoxPort";
            this.comboBoxPort.Size = new System.Drawing.Size(121, 20);
            this.comboBoxPort.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "ポート";
            // 
            // val1SendButton
            // 
            this.val1SendButton.Enabled = false;
            this.val1SendButton.Location = new System.Drawing.Point(154, 22);
            this.val1SendButton.Name = "val1SendButton";
            this.val1SendButton.Size = new System.Drawing.Size(57, 23);
            this.val1SendButton.TabIndex = 12;
            this.val1SendButton.Text = "送信";
            this.val1SendButton.UseVisualStyleBackColor = true;
            // 
            // buttonLogClear
            // 
            this.buttonLogClear.Location = new System.Drawing.Point(814, 446);
            this.buttonLogClear.Name = "buttonLogClear";
            this.buttonLogClear.Size = new System.Drawing.Size(93, 23);
            this.buttonLogClear.TabIndex = 51;
            this.buttonLogClear.Text = "ログクリア";
            this.buttonLogClear.UseVisualStyleBackColor = true;
            this.buttonLogClear.Click += new System.EventHandler(this.buttonLogClear_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Time,
            this.b,
            this.c,
            this.d,
            this.e,
            this.f,
            this.g,
            this.h,
            this.i,
            this.j,
            this.k,
            this.l});
            this.dataGridView.Location = new System.Drawing.Point(20, 446);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersWidth = 20;
            this.dataGridView.RowTemplate.Height = 21;
            this.dataGridView.Size = new System.Drawing.Size(782, 241);
            this.dataGridView.TabIndex = 9;
            this.dataGridView.TabStop = false;
            this.dataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellClick);
            // 
            // Time
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Time.DefaultCellStyle = dataGridViewCellStyle1;
            this.Time.HeaderText = "Tick";
            this.Time.Name = "Time";
            this.Time.ReadOnly = true;
            this.Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.Time.Width = 50;
            // 
            // b
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.b.DefaultCellStyle = dataGridViewCellStyle2;
            this.b.HeaderText = "S8_1";
            this.b.Name = "b";
            this.b.ReadOnly = true;
            this.b.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.b.Width = 50;
            // 
            // c
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.c.DefaultCellStyle = dataGridViewCellStyle3;
            this.c.HeaderText = "S8_2";
            this.c.Name = "c";
            this.c.ReadOnly = true;
            this.c.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.c.Width = 50;
            // 
            // d
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.d.DefaultCellStyle = dataGridViewCellStyle4;
            this.d.HeaderText = "光";
            this.d.Name = "d";
            this.d.ReadOnly = true;
            this.d.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.d.Width = 50;
            // 
            // e
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.e.DefaultCellStyle = dataGridViewCellStyle5;
            this.e.HeaderText = "しっぽ";
            this.e.Name = "e";
            this.e.ReadOnly = true;
            this.e.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.e.Width = 60;
            // 
            // f
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.f.DefaultCellStyle = dataGridViewCellStyle6;
            this.f.HeaderText = "モーター右";
            this.f.Name = "f";
            this.f.ReadOnly = true;
            this.f.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.f.Width = 80;
            // 
            // g
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.g.DefaultCellStyle = dataGridViewCellStyle7;
            this.g.HeaderText = "モーター左";
            this.g.Name = "g";
            this.g.ReadOnly = true;
            this.g.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.g.Width = 80;
            // 
            // h
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.h.DefaultCellStyle = dataGridViewCellStyle8;
            this.h.HeaderText = "S16_1";
            this.h.Name = "h";
            this.h.ReadOnly = true;
            this.h.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.h.Width = 50;
            // 
            // i
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.i.DefaultCellStyle = dataGridViewCellStyle9;
            this.i.HeaderText = "S16_2";
            this.i.Name = "i";
            this.i.ReadOnly = true;
            this.i.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.i.Width = 50;
            // 
            // j
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.j.DefaultCellStyle = dataGridViewCellStyle10;
            this.j.HeaderText = "S16_3";
            this.j.Name = "j";
            this.j.ReadOnly = true;
            this.j.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.j.Width = 50;
            // 
            // k
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.k.DefaultCellStyle = dataGridViewCellStyle11;
            this.k.HeaderText = "S16_4";
            this.k.Name = "k";
            this.k.ReadOnly = true;
            this.k.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.k.Width = 50;
            // 
            // l
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.l.DefaultCellStyle = dataGridViewCellStyle12;
            this.l.HeaderText = "超音波";
            this.l.Name = "l";
            this.l.ReadOnly = true;
            this.l.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.l.Width = 65;
            // 
            // chart0
            // 
            chartArea1.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea1.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea1.AxisX.LabelAutoFitStyle = ((System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles)(((((System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.IncreaseFont | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.DecreaseFont)
                        | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30)
                        | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep45)
                        | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep90)));
            chartArea1.AxisX.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea1.AxisX.MinorTickMark.Enabled = true;
            chartArea1.AxisY.IsStartedFromZero = false;
            chartArea1.AxisY.ScaleBreakStyle.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea1.CursorX.IsUserEnabled = true;
            chartArea1.CursorX.IsUserSelectionEnabled = true;
            chartArea1.CursorY.IsUserEnabled = true;
            chartArea1.CursorY.IsUserSelectionEnabled = true;
            chartArea1.InnerPlotPosition.Auto = false;
            chartArea1.InnerPlotPosition.Height = 75F;
            chartArea1.InnerPlotPosition.Width = 92F;
            chartArea1.InnerPlotPosition.X = 7F;
            chartArea1.InnerPlotPosition.Y = 5F;
            chartArea1.Name = "ChartArea1";
            chartArea1.Position.Auto = false;
            chartArea1.Position.Height = 100F;
            chartArea1.Position.Width = 100F;
            this.chart0.ChartAreas.Add(chartArea1);
            this.chart0.Location = new System.Drawing.Point(277, 12);
            this.chart0.Name = "chart0";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series1.MarkerColor = System.Drawing.Color.Red;
            series1.MarkerSize = 2;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "Series1";
            series1.ToolTip = "#VALX{D}, #VAL{D}";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chart0.Series.Add(series1);
            this.chart0.Size = new System.Drawing.Size(612, 136);
            this.chart0.TabIndex = 31;
            this.chart0.TabStop = false;
            this.chart0.Text = "chart1";
            // 
            // csvOutputButton
            // 
            this.csvOutputButton.Location = new System.Drawing.Point(814, 475);
            this.csvOutputButton.Name = "csvOutputButton";
            this.csvOutputButton.Size = new System.Drawing.Size(93, 23);
            this.csvOutputButton.TabIndex = 52;
            this.csvOutputButton.Text = "CSV出力";
            this.csvOutputButton.UseVisualStyleBackColor = true;
            this.csvOutputButton.Click += new System.EventHandler(this.csvOutputButton_Click);
            // 
            // csvInportButton
            // 
            this.csvInportButton.Location = new System.Drawing.Point(814, 504);
            this.csvInportButton.Name = "csvInportButton";
            this.csvInportButton.Size = new System.Drawing.Size(93, 23);
            this.csvInportButton.TabIndex = 53;
            this.csvInportButton.Text = "CSVインポート";
            this.csvInportButton.UseVisualStyleBackColor = true;
            this.csvInportButton.Click += new System.EventHandler(this.csvImportButton_Click);
            // 
            // val2SendButton
            // 
            this.val2SendButton.Enabled = false;
            this.val2SendButton.Location = new System.Drawing.Point(154, 47);
            this.val2SendButton.Name = "val2SendButton";
            this.val2SendButton.Size = new System.Drawing.Size(57, 23);
            this.val2SendButton.TabIndex = 14;
            this.val2SendButton.Text = "送信";
            this.val2SendButton.UseVisualStyleBackColor = true;
            // 
            // val3SendButton
            // 
            this.val3SendButton.Enabled = false;
            this.val3SendButton.Location = new System.Drawing.Point(154, 72);
            this.val3SendButton.Name = "val3SendButton";
            this.val3SendButton.Size = new System.Drawing.Size(57, 23);
            this.val3SendButton.TabIndex = 16;
            this.val3SendButton.Text = "送信";
            this.val3SendButton.UseVisualStyleBackColor = true;
            // 
            // val4SendButton
            // 
            this.val4SendButton.Enabled = false;
            this.val4SendButton.Location = new System.Drawing.Point(154, 97);
            this.val4SendButton.Name = "val4SendButton";
            this.val4SendButton.Size = new System.Drawing.Size(57, 23);
            this.val4SendButton.TabIndex = 18;
            this.val4SendButton.Text = "送信";
            this.val4SendButton.UseVisualStyleBackColor = true;
            // 
            // val5SendButton
            // 
            this.val5SendButton.Enabled = false;
            this.val5SendButton.Location = new System.Drawing.Point(154, 123);
            this.val5SendButton.Name = "val5SendButton";
            this.val5SendButton.Size = new System.Drawing.Size(57, 23);
            this.val5SendButton.TabIndex = 20;
            this.val5SendButton.Text = "送信";
            this.val5SendButton.UseVisualStyleBackColor = true;
            // 
            // val6SendButton
            // 
            this.val6SendButton.Enabled = false;
            this.val6SendButton.Location = new System.Drawing.Point(154, 147);
            this.val6SendButton.Name = "val6SendButton";
            this.val6SendButton.Size = new System.Drawing.Size(57, 23);
            this.val6SendButton.TabIndex = 22;
            this.val6SendButton.Text = "送信";
            this.val6SendButton.UseVisualStyleBackColor = true;
            // 
            // val7SendButton
            // 
            this.val7SendButton.Enabled = false;
            this.val7SendButton.Location = new System.Drawing.Point(154, 172);
            this.val7SendButton.Name = "val7SendButton";
            this.val7SendButton.Size = new System.Drawing.Size(57, 23);
            this.val7SendButton.TabIndex = 24;
            this.val7SendButton.Text = "送信";
            this.val7SendButton.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea2.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea2.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea2.AxisX.MinorTickMark.Enabled = true;
            chartArea2.AxisY.IsStartedFromZero = false;
            chartArea2.AxisY.ScaleBreakStyle.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea2.CursorX.IsUserEnabled = true;
            chartArea2.CursorX.IsUserSelectionEnabled = true;
            chartArea2.CursorY.IsUserEnabled = true;
            chartArea2.CursorY.IsUserSelectionEnabled = true;
            chartArea2.InnerPlotPosition.Auto = false;
            chartArea2.InnerPlotPosition.Height = 75F;
            chartArea2.InnerPlotPosition.Width = 92F;
            chartArea2.InnerPlotPosition.X = 7F;
            chartArea2.InnerPlotPosition.Y = 5F;
            chartArea2.Name = "ChartArea1";
            chartArea2.Position.Auto = false;
            chartArea2.Position.Height = 100F;
            chartArea2.Position.Width = 100F;
            this.chart1.ChartAreas.Add(chartArea2);
            this.chart1.Location = new System.Drawing.Point(277, 155);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series2.MarkerColor = System.Drawing.Color.Red;
            series2.MarkerSize = 2;
            series2.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series2.Name = "Series1";
            series2.ToolTip = "#VALX{D}, #VAL{D}";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            series2.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(612, 136);
            this.chart1.TabIndex = 32;
            this.chart1.TabStop = false;
            this.chart1.Text = "chart1";
            // 
            // chart2
            // 
            chartArea3.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea3.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea3.AxisX.MinorTickMark.Enabled = true;
            chartArea3.AxisY.IsStartedFromZero = false;
            chartArea3.AxisY.ScaleBreakStyle.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea3.CursorX.IsUserEnabled = true;
            chartArea3.CursorX.IsUserSelectionEnabled = true;
            chartArea3.CursorY.IsUserEnabled = true;
            chartArea3.CursorY.IsUserSelectionEnabled = true;
            chartArea3.InnerPlotPosition.Auto = false;
            chartArea3.InnerPlotPosition.Height = 75F;
            chartArea3.InnerPlotPosition.Width = 92F;
            chartArea3.InnerPlotPosition.X = 7F;
            chartArea3.InnerPlotPosition.Y = 5F;
            chartArea3.Name = "ChartArea1";
            chartArea3.Position.Auto = false;
            chartArea3.Position.Height = 100F;
            chartArea3.Position.Width = 100F;
            this.chart2.ChartAreas.Add(chartArea3);
            this.chart2.Location = new System.Drawing.Point(277, 298);
            this.chart2.Name = "chart2";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series3.MarkerColor = System.Drawing.Color.Red;
            series3.MarkerSize = 2;
            series3.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series3.Name = "Series1";
            series3.ToolTip = "#VALX{D}, #VAL{D}";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            series3.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chart2.Series.Add(series3);
            this.chart2.Size = new System.Drawing.Size(612, 136);
            this.chart2.TabIndex = 33;
            this.chart2.TabStop = false;
            this.chart2.Text = "chart1";
            // 
            // comboBoxChartingTarget0
            // 
            this.comboBoxChartingTarget0.DropDownHeight = 150;
            this.comboBoxChartingTarget0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChartingTarget0.FormattingEnabled = true;
            this.comboBoxChartingTarget0.IntegralHeight = false;
            this.comboBoxChartingTarget0.Items.AddRange(new object[] {
            "",
            "Tick",
            "S8_1",
            "S8_2",
            "光",
            "尻尾",
            "モータ右",
            "モータ左",
            "S16_1",
            "S16_2",
            "S16_3",
            "S16_4",
            "超音波"});
            this.comboBoxChartingTarget0.Location = new System.Drawing.Point(896, 12);
            this.comboBoxChartingTarget0.Name = "comboBoxChartingTarget0";
            this.comboBoxChartingTarget0.Size = new System.Drawing.Size(108, 20);
            this.comboBoxChartingTarget0.TabIndex = 41;
            // 
            // comboBoxChartingTarget1
            // 
            this.comboBoxChartingTarget1.DropDownHeight = 150;
            this.comboBoxChartingTarget1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChartingTarget1.FormattingEnabled = true;
            this.comboBoxChartingTarget1.IntegralHeight = false;
            this.comboBoxChartingTarget1.Items.AddRange(new object[] {
            "",
            "Tick",
            "S8_1",
            "S8_2",
            "光",
            "尻尾",
            "モータ右",
            "モータ左",
            "S16_1",
            "S16_2",
            "S16_3",
            "S16_4",
            "超音波"});
            this.comboBoxChartingTarget1.Location = new System.Drawing.Point(896, 155);
            this.comboBoxChartingTarget1.Name = "comboBoxChartingTarget1";
            this.comboBoxChartingTarget1.Size = new System.Drawing.Size(108, 20);
            this.comboBoxChartingTarget1.TabIndex = 42;
            // 
            // comboBoxChartingTarget2
            // 
            this.comboBoxChartingTarget2.DropDownHeight = 150;
            this.comboBoxChartingTarget2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChartingTarget2.FormattingEnabled = true;
            this.comboBoxChartingTarget2.IntegralHeight = false;
            this.comboBoxChartingTarget2.Items.AddRange(new object[] {
            "",
            "Tick",
            "S8_1",
            "S8_2",
            "光",
            "尻尾",
            "モータ右",
            "モータ左",
            "S16_1",
            "S16_2",
            "S16_3",
            "S16_4",
            "超音波"});
            this.comboBoxChartingTarget2.Location = new System.Drawing.Point(896, 298);
            this.comboBoxChartingTarget2.Name = "comboBoxChartingTarget2";
            this.comboBoxChartingTarget2.Size = new System.Drawing.Size(108, 20);
            this.comboBoxChartingTarget2.TabIndex = 43;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxVal1);
            this.groupBox1.Controls.Add(this.textBoxVal2);
            this.groupBox1.Controls.Add(this.textBoxVal3);
            this.groupBox1.Controls.Add(this.val7SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal4);
            this.groupBox1.Controls.Add(this.val6SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal5);
            this.groupBox1.Controls.Add(this.val5SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal6);
            this.groupBox1.Controls.Add(this.val4SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal7);
            this.groupBox1.Controls.Add(this.val3SendButton);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.val2SendButton);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.val1SendButton);
            this.groupBox1.Location = new System.Drawing.Point(20, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(231, 232);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "送信";
            // 
            // textBoxMaxLine
            // 
            this.textBoxMaxLine.Location = new System.Drawing.Point(20, 421);
            this.textBoxMaxLine.Name = "textBoxMaxLine";
            this.textBoxMaxLine.Size = new System.Drawing.Size(70, 19);
            this.textBoxMaxLine.TabIndex = 54;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(96, 424);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 55;
            this.label9.Text = "行を最大とする";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 699);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxMaxLine);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.comboBoxChartingTarget2);
            this.Controls.Add(this.comboBoxChartingTarget1);
            this.Controls.Add(this.comboBoxChartingTarget0);
            this.Controls.Add(this.csvInportButton);
            this.Controls.Add(this.csvOutputButton);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.chart0);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.buttonLogClear);
            this.Controls.Add(this.comboBoxPort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonConnect);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "NxtCommunicator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.TextBox textBoxVal1;
        private System.Windows.Forms.TextBox textBoxVal2;
        private System.Windows.Forms.TextBox textBoxVal3;
        private System.Windows.Forms.TextBox textBoxVal4;
        private System.Windows.Forms.TextBox textBoxVal5;
        private System.Windows.Forms.TextBox textBoxVal6;
        private System.Windows.Forms.TextBox textBoxVal7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button val1SendButton;
        private System.Windows.Forms.Button buttonLogClear;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart0;
        private System.Windows.Forms.Button csvOutputButton;
        private System.Windows.Forms.Button csvInportButton;
        private System.Windows.Forms.Button val2SendButton;
        private System.Windows.Forms.Button val3SendButton;
        private System.Windows.Forms.Button val4SendButton;
        private System.Windows.Forms.Button val5SendButton;
        private System.Windows.Forms.Button val6SendButton;
        private System.Windows.Forms.Button val7SendButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Time;
        private System.Windows.Forms.DataGridViewTextBoxColumn b;
        private System.Windows.Forms.DataGridViewTextBoxColumn c;
        private System.Windows.Forms.DataGridViewTextBoxColumn d;
        private System.Windows.Forms.DataGridViewTextBoxColumn e;
        private System.Windows.Forms.DataGridViewTextBoxColumn f;
        private System.Windows.Forms.DataGridViewTextBoxColumn g;
        private System.Windows.Forms.DataGridViewTextBoxColumn h;
        private System.Windows.Forms.DataGridViewTextBoxColumn i;
        private System.Windows.Forms.DataGridViewTextBoxColumn j;
        private System.Windows.Forms.DataGridViewTextBoxColumn k;
        private System.Windows.Forms.DataGridViewTextBoxColumn l;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.ComboBox comboBoxChartingTarget0;
        private System.Windows.Forms.ComboBox comboBoxChartingTarget1;
        private System.Windows.Forms.ComboBox comboBoxChartingTarget2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxMaxLine;
        private System.Windows.Forms.Label label9;
    }
}

