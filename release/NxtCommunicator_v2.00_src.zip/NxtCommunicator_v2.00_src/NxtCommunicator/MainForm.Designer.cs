﻿namespace NxtCommunicator
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.buttonConnect = new System.Windows.Forms.Button();
            this.textBoxVal1 = new System.Windows.Forms.TextBox();
            this.textBoxVal2 = new System.Windows.Forms.TextBox();
            this.textBoxVal3 = new System.Windows.Forms.TextBox();
            this.textBoxVal4 = new System.Windows.Forms.TextBox();
            this.textBoxVal5 = new System.Windows.Forms.TextBox();
            this.textBoxVal6 = new System.Windows.Forms.TextBox();
            this.textBoxVal7 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxPort = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.val1SendButton = new System.Windows.Forms.Button();
            this.buttonLogClear = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.b = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.d = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.e = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.f = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.h = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.i = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.j = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.k = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.l = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chart0 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.csvOutputButton = new System.Windows.Forms.Button();
            this.csvInportButton = new System.Windows.Forms.Button();
            this.val2SendButton = new System.Windows.Forms.Button();
            this.val3SendButton = new System.Windows.Forms.Button();
            this.val4SendButton = new System.Windows.Forms.Button();
            this.val5SendButton = new System.Windows.Forms.Button();
            this.val6SendButton = new System.Windows.Forms.Button();
            this.val7SendButton = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBoxChartingTarget0 = new System.Windows.Forms.ComboBox();
            this.comboBoxChartingTarget1 = new System.Windows.Forms.ComboBox();
            this.comboBoxChartingTarget2 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panelCourse = new System.Windows.Forms.Panel();
            this.pictureBoxNxtMukiEast = new System.Windows.Forms.PictureBox();
            this.pictureBoxNxtMukiWest = new System.Windows.Forms.PictureBox();
            this.pictureBoxNxtMukiNorth = new System.Windows.Forms.PictureBox();
            this.pictureBoxNxtMukiSouth = new System.Windows.Forms.PictureBox();
            this.pictureBoxPoint = new System.Windows.Forms.PictureBox();
            this.buttonPlay = new System.Windows.Forms.Button();
            this.buttonPlayerStop = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numUpDownCourseScale = new System.Windows.Forms.NumericUpDown();
            this.buttonClear = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxKakudo = new System.Windows.Forms.TextBox();
            this.labelShajiku = new System.Windows.Forms.Label();
            this.labelTireRadius = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageLog = new System.Windows.Forms.TabPage();
            this.numUpDownMaxLine = new System.Windows.Forms.NumericUpDown();
            this.tabPageMovie = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPageSetting = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numUpDownTireRadius = new System.Windows.Forms.NumericUpDown();
            this.numUpDownShajikuLen = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.numericUpDownPlaySpeed = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panelCourse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiEast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiWest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiNorth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiSouth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPoint)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCourseScale)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabPageLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownMaxLine)).BeginInit();
            this.tabPageMovie.SuspendLayout();
            this.tabPageSetting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownTireRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownShajikuLen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPlaySpeed)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(194, 12);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(57, 23);
            this.buttonConnect.TabIndex = 2;
            this.buttonConnect.Text = "接続";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // textBoxVal1
            // 
            this.textBoxVal1.Location = new System.Drawing.Point(45, 18);
            this.textBoxVal1.Name = "textBoxVal1";
            this.textBoxVal1.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal1.TabIndex = 11;
            // 
            // textBoxVal2
            // 
            this.textBoxVal2.Location = new System.Drawing.Point(45, 43);
            this.textBoxVal2.Name = "textBoxVal2";
            this.textBoxVal2.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal2.TabIndex = 13;
            // 
            // textBoxVal3
            // 
            this.textBoxVal3.Location = new System.Drawing.Point(45, 69);
            this.textBoxVal3.Name = "textBoxVal3";
            this.textBoxVal3.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal3.TabIndex = 15;
            // 
            // textBoxVal4
            // 
            this.textBoxVal4.Location = new System.Drawing.Point(45, 93);
            this.textBoxVal4.Name = "textBoxVal4";
            this.textBoxVal4.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal4.TabIndex = 17;
            // 
            // textBoxVal5
            // 
            this.textBoxVal5.Location = new System.Drawing.Point(45, 118);
            this.textBoxVal5.Name = "textBoxVal5";
            this.textBoxVal5.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal5.TabIndex = 19;
            // 
            // textBoxVal6
            // 
            this.textBoxVal6.Location = new System.Drawing.Point(45, 143);
            this.textBoxVal6.Name = "textBoxVal6";
            this.textBoxVal6.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal6.TabIndex = 21;
            // 
            // textBoxVal7
            // 
            this.textBoxVal7.Location = new System.Drawing.Point(45, 168);
            this.textBoxVal7.Name = "textBoxVal7";
            this.textBoxVal7.Size = new System.Drawing.Size(98, 19);
            this.textBoxVal7.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "値１";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "値２";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "値３";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "値４";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "値５";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "値６";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "値７";
            // 
            // comboBoxPort
            // 
            this.comboBoxPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPort.FormattingEnabled = true;
            this.comboBoxPort.Location = new System.Drawing.Point(57, 14);
            this.comboBoxPort.Name = "comboBoxPort";
            this.comboBoxPort.Size = new System.Drawing.Size(121, 20);
            this.comboBoxPort.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "ポート";
            // 
            // val1SendButton
            // 
            this.val1SendButton.Enabled = false;
            this.val1SendButton.Location = new System.Drawing.Point(149, 16);
            this.val1SendButton.Name = "val1SendButton";
            this.val1SendButton.Size = new System.Drawing.Size(57, 23);
            this.val1SendButton.TabIndex = 12;
            this.val1SendButton.Text = "送信";
            this.val1SendButton.UseVisualStyleBackColor = true;
            // 
            // buttonLogClear
            // 
            this.buttonLogClear.Location = new System.Drawing.Point(690, 727);
            this.buttonLogClear.Name = "buttonLogClear";
            this.buttonLogClear.Size = new System.Drawing.Size(93, 23);
            this.buttonLogClear.TabIndex = 51;
            this.buttonLogClear.Text = "Log Clear";
            this.buttonLogClear.UseVisualStyleBackColor = true;
            this.buttonLogClear.Click += new System.EventHandler(this.buttonLogClear_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Time,
            this.b,
            this.c,
            this.d,
            this.e,
            this.f,
            this.g,
            this.h,
            this.i,
            this.j,
            this.k,
            this.l});
            this.dataGridView.Location = new System.Drawing.Point(6, 0);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersWidth = 20;
            this.dataGridView.RowTemplate.Height = 21;
            this.dataGridView.Size = new System.Drawing.Size(707, 241);
            this.dataGridView.TabIndex = 9;
            this.dataGridView.TabStop = false;
            this.dataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellClick);
            // 
            // Time
            // 
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Time.DefaultCellStyle = dataGridViewCellStyle25;
            this.Time.HeaderText = "Tick";
            this.Time.Name = "Time";
            this.Time.ReadOnly = true;
            this.Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.Time.Width = 50;
            // 
            // b
            // 
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.b.DefaultCellStyle = dataGridViewCellStyle26;
            this.b.HeaderText = "S8_1";
            this.b.Name = "b";
            this.b.ReadOnly = true;
            this.b.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.b.Width = 50;
            // 
            // c
            // 
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.c.DefaultCellStyle = dataGridViewCellStyle27;
            this.c.HeaderText = "S8_2";
            this.c.Name = "c";
            this.c.ReadOnly = true;
            this.c.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.c.Width = 50;
            // 
            // d
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.d.DefaultCellStyle = dataGridViewCellStyle28;
            this.d.HeaderText = "光";
            this.d.Name = "d";
            this.d.ReadOnly = true;
            this.d.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.d.Width = 50;
            // 
            // e
            // 
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.e.DefaultCellStyle = dataGridViewCellStyle29;
            this.e.HeaderText = "しっぽ";
            this.e.Name = "e";
            this.e.ReadOnly = true;
            this.e.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.e.Width = 60;
            // 
            // f
            // 
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.f.DefaultCellStyle = dataGridViewCellStyle30;
            this.f.HeaderText = "モーター右";
            this.f.Name = "f";
            this.f.ReadOnly = true;
            this.f.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.f.Width = 80;
            // 
            // g
            // 
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.g.DefaultCellStyle = dataGridViewCellStyle31;
            this.g.HeaderText = "モーター左";
            this.g.Name = "g";
            this.g.ReadOnly = true;
            this.g.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.g.Width = 80;
            // 
            // h
            // 
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.h.DefaultCellStyle = dataGridViewCellStyle32;
            this.h.HeaderText = "S16_1";
            this.h.Name = "h";
            this.h.ReadOnly = true;
            this.h.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.h.Width = 50;
            // 
            // i
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.i.DefaultCellStyle = dataGridViewCellStyle33;
            this.i.HeaderText = "S16_2";
            this.i.Name = "i";
            this.i.ReadOnly = true;
            this.i.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.i.Width = 50;
            // 
            // j
            // 
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.j.DefaultCellStyle = dataGridViewCellStyle34;
            this.j.HeaderText = "S16_3";
            this.j.Name = "j";
            this.j.ReadOnly = true;
            this.j.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.j.Width = 50;
            // 
            // k
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.k.DefaultCellStyle = dataGridViewCellStyle35;
            this.k.HeaderText = "S16_4";
            this.k.Name = "k";
            this.k.ReadOnly = true;
            this.k.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.k.Width = 50;
            // 
            // l
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.l.DefaultCellStyle = dataGridViewCellStyle36;
            this.l.HeaderText = "超音波";
            this.l.Name = "l";
            this.l.ReadOnly = true;
            this.l.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.l.Width = 65;
            // 
            // chart0
            // 
            chartArea7.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea7.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea7.AxisX.LabelAutoFitStyle = ((System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles)(((((System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.IncreaseFont | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.DecreaseFont) 
            | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30) 
            | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep45) 
            | System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep90)));
            chartArea7.AxisX.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea7.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea7.AxisX.MinorTickMark.Enabled = true;
            chartArea7.AxisY.IsStartedFromZero = false;
            chartArea7.AxisY.ScaleBreakStyle.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea7.CursorX.IsUserEnabled = true;
            chartArea7.CursorX.IsUserSelectionEnabled = true;
            chartArea7.CursorY.IsUserEnabled = true;
            chartArea7.CursorY.IsUserSelectionEnabled = true;
            chartArea7.InnerPlotPosition.Auto = false;
            chartArea7.InnerPlotPosition.Height = 75F;
            chartArea7.InnerPlotPosition.Width = 92F;
            chartArea7.InnerPlotPosition.X = 7F;
            chartArea7.InnerPlotPosition.Y = 5F;
            chartArea7.Name = "ChartArea1";
            chartArea7.Position.Auto = false;
            chartArea7.Position.Height = 100F;
            chartArea7.Position.Width = 100F;
            this.chart0.ChartAreas.Add(chartArea7);
            this.chart0.Location = new System.Drawing.Point(274, 12);
            this.chart0.Name = "chart0";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series7.MarkerColor = System.Drawing.Color.Red;
            series7.MarkerSize = 2;
            series7.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series7.Name = "Series1";
            series7.ToolTip = "#VALX{D}, #VAL{D}";
            series7.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            series7.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chart0.Series.Add(series7);
            this.chart0.Size = new System.Drawing.Size(645, 136);
            this.chart0.TabIndex = 31;
            this.chart0.TabStop = false;
            this.chart0.Text = "chart1";
            // 
            // csvOutputButton
            // 
            this.csvOutputButton.Location = new System.Drawing.Point(808, 727);
            this.csvOutputButton.Name = "csvOutputButton";
            this.csvOutputButton.Size = new System.Drawing.Size(93, 23);
            this.csvOutputButton.TabIndex = 52;
            this.csvOutputButton.Text = "CSV Export";
            this.csvOutputButton.UseVisualStyleBackColor = true;
            this.csvOutputButton.Click += new System.EventHandler(this.csvOutputButton_Click);
            // 
            // csvInportButton
            // 
            this.csvInportButton.Location = new System.Drawing.Point(907, 727);
            this.csvInportButton.Name = "csvInportButton";
            this.csvInportButton.Size = new System.Drawing.Size(93, 23);
            this.csvInportButton.TabIndex = 53;
            this.csvInportButton.Text = "CSV Import";
            this.csvInportButton.UseVisualStyleBackColor = true;
            this.csvInportButton.Click += new System.EventHandler(this.csvImportButton_Click);
            // 
            // val2SendButton
            // 
            this.val2SendButton.Enabled = false;
            this.val2SendButton.Location = new System.Drawing.Point(149, 41);
            this.val2SendButton.Name = "val2SendButton";
            this.val2SendButton.Size = new System.Drawing.Size(57, 23);
            this.val2SendButton.TabIndex = 14;
            this.val2SendButton.Text = "送信";
            this.val2SendButton.UseVisualStyleBackColor = true;
            // 
            // val3SendButton
            // 
            this.val3SendButton.Enabled = false;
            this.val3SendButton.Location = new System.Drawing.Point(149, 66);
            this.val3SendButton.Name = "val3SendButton";
            this.val3SendButton.Size = new System.Drawing.Size(57, 23);
            this.val3SendButton.TabIndex = 16;
            this.val3SendButton.Text = "送信";
            this.val3SendButton.UseVisualStyleBackColor = true;
            // 
            // val4SendButton
            // 
            this.val4SendButton.Enabled = false;
            this.val4SendButton.Location = new System.Drawing.Point(149, 91);
            this.val4SendButton.Name = "val4SendButton";
            this.val4SendButton.Size = new System.Drawing.Size(57, 23);
            this.val4SendButton.TabIndex = 18;
            this.val4SendButton.Text = "送信";
            this.val4SendButton.UseVisualStyleBackColor = true;
            // 
            // val5SendButton
            // 
            this.val5SendButton.Enabled = false;
            this.val5SendButton.Location = new System.Drawing.Point(149, 117);
            this.val5SendButton.Name = "val5SendButton";
            this.val5SendButton.Size = new System.Drawing.Size(57, 23);
            this.val5SendButton.TabIndex = 20;
            this.val5SendButton.Text = "送信";
            this.val5SendButton.UseVisualStyleBackColor = true;
            // 
            // val6SendButton
            // 
            this.val6SendButton.Enabled = false;
            this.val6SendButton.Location = new System.Drawing.Point(149, 141);
            this.val6SendButton.Name = "val6SendButton";
            this.val6SendButton.Size = new System.Drawing.Size(57, 23);
            this.val6SendButton.TabIndex = 22;
            this.val6SendButton.Text = "送信";
            this.val6SendButton.UseVisualStyleBackColor = true;
            // 
            // val7SendButton
            // 
            this.val7SendButton.Enabled = false;
            this.val7SendButton.Location = new System.Drawing.Point(149, 166);
            this.val7SendButton.Name = "val7SendButton";
            this.val7SendButton.Size = new System.Drawing.Size(57, 23);
            this.val7SendButton.TabIndex = 24;
            this.val7SendButton.Text = "送信";
            this.val7SendButton.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea8.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea8.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea8.AxisX.MinorTickMark.Enabled = true;
            chartArea8.AxisY.IsStartedFromZero = false;
            chartArea8.AxisY.ScaleBreakStyle.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea8.CursorX.IsUserEnabled = true;
            chartArea8.CursorX.IsUserSelectionEnabled = true;
            chartArea8.CursorY.IsUserEnabled = true;
            chartArea8.CursorY.IsUserSelectionEnabled = true;
            chartArea8.InnerPlotPosition.Auto = false;
            chartArea8.InnerPlotPosition.Height = 75F;
            chartArea8.InnerPlotPosition.Width = 92F;
            chartArea8.InnerPlotPosition.X = 7F;
            chartArea8.InnerPlotPosition.Y = 5F;
            chartArea8.Name = "ChartArea1";
            chartArea8.Position.Auto = false;
            chartArea8.Position.Height = 100F;
            chartArea8.Position.Width = 100F;
            this.chart1.ChartAreas.Add(chartArea8);
            this.chart1.Location = new System.Drawing.Point(274, 155);
            this.chart1.Name = "chart1";
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series8.MarkerColor = System.Drawing.Color.Red;
            series8.MarkerSize = 2;
            series8.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series8.Name = "Series1";
            series8.ToolTip = "#VALX{D}, #VAL{D}";
            series8.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            series8.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chart1.Series.Add(series8);
            this.chart1.Size = new System.Drawing.Size(645, 136);
            this.chart1.TabIndex = 32;
            this.chart1.TabStop = false;
            this.chart1.Text = "chart1";
            // 
            // chart2
            // 
            chartArea9.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea9.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea9.AxisX.MinorTickMark.Enabled = true;
            chartArea9.AxisY.IsStartedFromZero = false;
            chartArea9.AxisY.ScaleBreakStyle.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea9.CursorX.IsUserEnabled = true;
            chartArea9.CursorX.IsUserSelectionEnabled = true;
            chartArea9.CursorY.IsUserEnabled = true;
            chartArea9.CursorY.IsUserSelectionEnabled = true;
            chartArea9.InnerPlotPosition.Auto = false;
            chartArea9.InnerPlotPosition.Height = 75F;
            chartArea9.InnerPlotPosition.Width = 92F;
            chartArea9.InnerPlotPosition.X = 7F;
            chartArea9.InnerPlotPosition.Y = 5F;
            chartArea9.Name = "ChartArea1";
            chartArea9.Position.Auto = false;
            chartArea9.Position.Height = 100F;
            chartArea9.Position.Width = 100F;
            this.chart2.ChartAreas.Add(chartArea9);
            this.chart2.Location = new System.Drawing.Point(274, 298);
            this.chart2.Name = "chart2";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series9.MarkerColor = System.Drawing.Color.Red;
            series9.MarkerSize = 2;
            series9.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series9.Name = "Series1";
            series9.ToolTip = "#VALX{D}, #VAL{D}";
            series9.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            series9.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chart2.Series.Add(series9);
            this.chart2.Size = new System.Drawing.Size(645, 136);
            this.chart2.TabIndex = 33;
            this.chart2.TabStop = false;
            this.chart2.Text = "chart1";
            // 
            // comboBoxChartingTarget0
            // 
            this.comboBoxChartingTarget0.DropDownHeight = 150;
            this.comboBoxChartingTarget0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChartingTarget0.FormattingEnabled = true;
            this.comboBoxChartingTarget0.IntegralHeight = false;
            this.comboBoxChartingTarget0.Items.AddRange(new object[] {
            "",
            "Tick",
            "S8_1",
            "S8_2",
            "光",
            "尻尾",
            "モータ右",
            "モータ左",
            "S16_1",
            "S16_2",
            "S16_3",
            "S16_4",
            "超音波"});
            this.comboBoxChartingTarget0.Location = new System.Drawing.Point(925, 12);
            this.comboBoxChartingTarget0.Name = "comboBoxChartingTarget0";
            this.comboBoxChartingTarget0.Size = new System.Drawing.Size(79, 20);
            this.comboBoxChartingTarget0.TabIndex = 41;
            // 
            // comboBoxChartingTarget1
            // 
            this.comboBoxChartingTarget1.DropDownHeight = 150;
            this.comboBoxChartingTarget1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChartingTarget1.FormattingEnabled = true;
            this.comboBoxChartingTarget1.IntegralHeight = false;
            this.comboBoxChartingTarget1.Items.AddRange(new object[] {
            "",
            "Tick",
            "S8_1",
            "S8_2",
            "光",
            "尻尾",
            "モータ右",
            "モータ左",
            "S16_1",
            "S16_2",
            "S16_3",
            "S16_4",
            "超音波"});
            this.comboBoxChartingTarget1.Location = new System.Drawing.Point(925, 155);
            this.comboBoxChartingTarget1.Name = "comboBoxChartingTarget1";
            this.comboBoxChartingTarget1.Size = new System.Drawing.Size(79, 20);
            this.comboBoxChartingTarget1.TabIndex = 42;
            // 
            // comboBoxChartingTarget2
            // 
            this.comboBoxChartingTarget2.DropDownHeight = 150;
            this.comboBoxChartingTarget2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChartingTarget2.FormattingEnabled = true;
            this.comboBoxChartingTarget2.IntegralHeight = false;
            this.comboBoxChartingTarget2.Items.AddRange(new object[] {
            "",
            "Tick",
            "S8_1",
            "S8_2",
            "光",
            "尻尾",
            "モータ右",
            "モータ左",
            "S16_1",
            "S16_2",
            "S16_3",
            "S16_4",
            "超音波"});
            this.comboBoxChartingTarget2.Location = new System.Drawing.Point(925, 298);
            this.comboBoxChartingTarget2.Name = "comboBoxChartingTarget2";
            this.comboBoxChartingTarget2.Size = new System.Drawing.Size(79, 20);
            this.comboBoxChartingTarget2.TabIndex = 43;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxVal1);
            this.groupBox1.Controls.Add(this.textBoxVal2);
            this.groupBox1.Controls.Add(this.textBoxVal3);
            this.groupBox1.Controls.Add(this.val7SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal4);
            this.groupBox1.Controls.Add(this.val6SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal5);
            this.groupBox1.Controls.Add(this.val5SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal6);
            this.groupBox1.Controls.Add(this.val4SendButton);
            this.groupBox1.Controls.Add(this.textBoxVal7);
            this.groupBox1.Controls.Add(this.val3SendButton);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.val2SendButton);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.val1SendButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(256, 194);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "送信";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(839, 218);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 12);
            this.label9.TabIndex = 55;
            this.label9.Text = "行まで保持";
            // 
            // panelCourse
            // 
            this.panelCourse.AllowDrop = true;
            this.panelCourse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelCourse.BackgroundImage")));
            this.panelCourse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelCourse.Controls.Add(this.pictureBoxNxtMukiEast);
            this.panelCourse.Controls.Add(this.pictureBoxNxtMukiWest);
            this.panelCourse.Controls.Add(this.pictureBoxNxtMukiNorth);
            this.panelCourse.Controls.Add(this.pictureBoxNxtMukiSouth);
            this.panelCourse.Controls.Add(this.pictureBoxPoint);
            this.panelCourse.Location = new System.Drawing.Point(8, 15);
            this.panelCourse.Name = "panelCourse";
            this.panelCourse.Size = new System.Drawing.Size(167, 148);
            this.panelCourse.TabIndex = 57;
            this.panelCourse.DragDrop += new System.Windows.Forms.DragEventHandler(this.panelCourse_DragDrop);
            this.panelCourse.DragEnter += new System.Windows.Forms.DragEventHandler(this.panelCourse_DragEnter);
            this.panelCourse.DragOver += new System.Windows.Forms.DragEventHandler(this.panelCourse_DragOver);
            // 
            // pictureBoxNxtMukiEast
            // 
            this.pictureBoxNxtMukiEast.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxNxtMukiEast.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxNxtMukiEast.Image")));
            this.pictureBoxNxtMukiEast.Location = new System.Drawing.Point(109, 54);
            this.pictureBoxNxtMukiEast.Name = "pictureBoxNxtMukiEast";
            this.pictureBoxNxtMukiEast.Size = new System.Drawing.Size(33, 27);
            this.pictureBoxNxtMukiEast.TabIndex = 62;
            this.pictureBoxNxtMukiEast.TabStop = false;
            this.pictureBoxNxtMukiEast.Click += new System.EventHandler(this.pictureBoxNxtMukiEast_Click);
            // 
            // pictureBoxNxtMukiWest
            // 
            this.pictureBoxNxtMukiWest.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxNxtMukiWest.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxNxtMukiWest.Image")));
            this.pictureBoxNxtMukiWest.Location = new System.Drawing.Point(37, 54);
            this.pictureBoxNxtMukiWest.Name = "pictureBoxNxtMukiWest";
            this.pictureBoxNxtMukiWest.Size = new System.Drawing.Size(30, 27);
            this.pictureBoxNxtMukiWest.TabIndex = 62;
            this.pictureBoxNxtMukiWest.TabStop = false;
            this.pictureBoxNxtMukiWest.Click += new System.EventHandler(this.pictureBoxNxtMukiWest_Click);
            // 
            // pictureBoxNxtMukiNorth
            // 
            this.pictureBoxNxtMukiNorth.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxNxtMukiNorth.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxNxtMukiNorth.Image")));
            this.pictureBoxNxtMukiNorth.Location = new System.Drawing.Point(73, 27);
            this.pictureBoxNxtMukiNorth.Name = "pictureBoxNxtMukiNorth";
            this.pictureBoxNxtMukiNorth.Size = new System.Drawing.Size(29, 34);
            this.pictureBoxNxtMukiNorth.TabIndex = 62;
            this.pictureBoxNxtMukiNorth.TabStop = false;
            this.pictureBoxNxtMukiNorth.Click += new System.EventHandler(this.pictureBoxNxtMukiNorth_Click);
            // 
            // pictureBoxNxtMukiSouth
            // 
            this.pictureBoxNxtMukiSouth.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxNxtMukiSouth.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxNxtMukiSouth.Image")));
            this.pictureBoxNxtMukiSouth.Location = new System.Drawing.Point(73, 77);
            this.pictureBoxNxtMukiSouth.Name = "pictureBoxNxtMukiSouth";
            this.pictureBoxNxtMukiSouth.Size = new System.Drawing.Size(28, 32);
            this.pictureBoxNxtMukiSouth.TabIndex = 62;
            this.pictureBoxNxtMukiSouth.TabStop = false;
            this.pictureBoxNxtMukiSouth.Click += new System.EventHandler(this.pictureBoxNxtMukiSouth_Click);
            // 
            // pictureBoxPoint
            // 
            this.pictureBoxPoint.Image = global::NxtCommunicator.Properties.Resources.Point;
            this.pictureBoxPoint.Location = new System.Drawing.Point(141, 99);
            this.pictureBoxPoint.Name = "pictureBoxPoint";
            this.pictureBoxPoint.Size = new System.Drawing.Size(10, 10);
            this.pictureBoxPoint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPoint.TabIndex = 58;
            this.pictureBoxPoint.TabStop = false;
            this.pictureBoxPoint.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.pictureBoxPoint_QueryContinueDrag);
            this.pictureBoxPoint.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxPoint_MouseDown);
            this.pictureBoxPoint.MouseLeave += new System.EventHandler(this.pictureBoxPoint_MouseLeave);
            this.pictureBoxPoint.MouseHover += new System.EventHandler(this.pictureBoxPoint_MouseHover);
            this.pictureBoxPoint.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxPoint_MouseMove);
            this.pictureBoxPoint.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBoxPoint_MouseUp);
            // 
            // buttonPlay
            // 
            this.buttonPlay.Image = ((System.Drawing.Image)(resources.GetObject("buttonPlay.Image")));
            this.buttonPlay.Location = new System.Drawing.Point(70, 713);
            this.buttonPlay.Name = "buttonPlay";
            this.buttonPlay.Size = new System.Drawing.Size(51, 37);
            this.buttonPlay.TabIndex = 58;
            this.buttonPlay.UseVisualStyleBackColor = true;
            this.buttonPlay.Click += new System.EventHandler(this.buttonPlay_Click);
            // 
            // buttonPlayerStop
            // 
            this.buttonPlayerStop.Image = ((System.Drawing.Image)(resources.GetObject("buttonPlayerStop.Image")));
            this.buttonPlayerStop.Location = new System.Drawing.Point(127, 713);
            this.buttonPlayerStop.Name = "buttonPlayerStop";
            this.buttonPlayerStop.Size = new System.Drawing.Size(51, 37);
            this.buttonPlayerStop.TabIndex = 59;
            this.buttonPlayerStop.UseVisualStyleBackColor = true;
            this.buttonPlayerStop.Click += new System.EventHandler(this.buttonPlayerStop_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numUpDownCourseScale);
            this.groupBox2.Controls.Add(this.buttonClear);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.panelCourse);
            this.groupBox2.Controls.Add(this.textBoxKakudo);
            this.groupBox2.Location = new System.Drawing.Point(12, 240);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(256, 194);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Course";
            // 
            // numUpDownCourseScale
            // 
            this.numUpDownCourseScale.DecimalPlaces = 4;
            this.numUpDownCourseScale.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.numUpDownCourseScale.Location = new System.Drawing.Point(95, 169);
            this.numUpDownCourseScale.Name = "numUpDownCourseScale";
            this.numUpDownCourseScale.Size = new System.Drawing.Size(71, 19);
            this.numUpDownCourseScale.TabIndex = 64;
            this.numUpDownCourseScale.Value = new decimal(new int[] {
            12,
            0,
            0,
            65536});
            this.numUpDownCourseScale.Leave += new System.EventHandler(this.numUpDownCourseScale_Leave);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(181, 140);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(50, 23);
            this.buttonClear.TabIndex = 63;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 12);
            this.label10.TabIndex = 62;
            this.label10.Text = "軌跡の縮小率";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxKakudo
            // 
            this.textBoxKakudo.Location = new System.Drawing.Point(182, 169);
            this.textBoxKakudo.Name = "textBoxKakudo";
            this.textBoxKakudo.Size = new System.Drawing.Size(50, 19);
            this.textBoxKakudo.TabIndex = 61;
            this.textBoxKakudo.Text = "270";
            this.textBoxKakudo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxKakudo.Visible = false;
            // 
            // labelShajiku
            // 
            this.labelShajiku.AutoSize = true;
            this.labelShajiku.Location = new System.Drawing.Point(44, 41);
            this.labelShajiku.Name = "labelShajiku";
            this.labelShajiku.Size = new System.Drawing.Size(29, 12);
            this.labelShajiku.TabIndex = 62;
            this.labelShajiku.Text = "車軸";
            this.labelShajiku.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTireRadius
            // 
            this.labelTireRadius.AutoSize = true;
            this.labelTireRadius.Location = new System.Drawing.Point(17, 66);
            this.labelTireRadius.Name = "labelTireRadius";
            this.labelTireRadius.Size = new System.Drawing.Size(56, 12);
            this.labelTireRadius.TabIndex = 62;
            this.labelTireRadius.Text = "タイヤ半径";
            this.labelTireRadius.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPageLog);
            this.tabControl.Controls.Add(this.tabPageMovie);
            this.tabControl.Controls.Add(this.tabPageSetting);
            this.tabControl.Location = new System.Drawing.Point(15, 440);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(989, 267);
            this.tabControl.TabIndex = 61;
            // 
            // tabPageLog
            // 
            this.tabPageLog.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tabPageLog.Controls.Add(this.numUpDownMaxLine);
            this.tabPageLog.Controls.Add(this.dataGridView);
            this.tabPageLog.Controls.Add(this.label9);
            this.tabPageLog.Location = new System.Drawing.Point(4, 22);
            this.tabPageLog.Name = "tabPageLog";
            this.tabPageLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLog.Size = new System.Drawing.Size(981, 241);
            this.tabPageLog.TabIndex = 0;
            this.tabPageLog.Text = "Log";
            // 
            // numUpDownMaxLine
            // 
            this.numUpDownMaxLine.Location = new System.Drawing.Point(719, 216);
            this.numUpDownMaxLine.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.numUpDownMaxLine.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDownMaxLine.Name = "numUpDownMaxLine";
            this.numUpDownMaxLine.Size = new System.Drawing.Size(114, 19);
            this.numUpDownMaxLine.TabIndex = 65;
            this.numUpDownMaxLine.Value = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            // 
            // tabPageMovie
            // 
            this.tabPageMovie.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tabPageMovie.Controls.Add(this.label12);
            this.tabPageMovie.Location = new System.Drawing.Point(4, 22);
            this.tabPageMovie.Name = "tabPageMovie";
            this.tabPageMovie.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMovie.Size = new System.Drawing.Size(981, 241);
            this.tabPageMovie.TabIndex = 1;
            this.tabPageMovie.Text = "Movie";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(407, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 27);
            this.label12.TabIndex = 0;
            this.label12.Text = "ToDo";
            // 
            // tabPageSetting
            // 
            this.tabPageSetting.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tabPageSetting.Controls.Add(this.groupBox3);
            this.tabPageSetting.Location = new System.Drawing.Point(4, 22);
            this.tabPageSetting.Name = "tabPageSetting";
            this.tabPageSetting.Size = new System.Drawing.Size(981, 241);
            this.tabPageSetting.TabIndex = 2;
            this.tabPageSetting.Text = "Setting";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numUpDownTireRadius);
            this.groupBox3.Controls.Add(this.numUpDownShajikuLen);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.labelShajiku);
            this.groupBox3.Controls.Add(this.labelTireRadius);
            this.groupBox3.Location = new System.Drawing.Point(9, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(244, 103);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "NXT";
            // 
            // numUpDownTireRadius
            // 
            this.numUpDownTireRadius.DecimalPlaces = 2;
            this.numUpDownTireRadius.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numUpDownTireRadius.Location = new System.Drawing.Point(79, 64);
            this.numUpDownTireRadius.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numUpDownTireRadius.Name = "numUpDownTireRadius";
            this.numUpDownTireRadius.Size = new System.Drawing.Size(71, 19);
            this.numUpDownTireRadius.TabIndex = 64;
            this.numUpDownTireRadius.Value = new decimal(new int[] {
            417,
            0,
            0,
            131072});
            this.numUpDownTireRadius.Leave += new System.EventHandler(this.numUpDownTireRadius_Leave);
            // 
            // numUpDownShajikuLen
            // 
            this.numUpDownShajikuLen.DecimalPlaces = 1;
            this.numUpDownShajikuLen.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numUpDownShajikuLen.Location = new System.Drawing.Point(79, 38);
            this.numUpDownShajikuLen.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numUpDownShajikuLen.Name = "numUpDownShajikuLen";
            this.numUpDownShajikuLen.Size = new System.Drawing.Size(71, 19);
            this.numUpDownShajikuLen.TabIndex = 64;
            this.numUpDownShajikuLen.Value = new decimal(new int[] {
            168,
            0,
            0,
            65536});
            this.numUpDownShajikuLen.Leave += new System.EventHandler(this.numUpDownShajikuLen_Leave);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(167, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "走行軌跡の演算で使用されます。";
            // 
            // numericUpDownPlaySpeed
            // 
            this.numericUpDownPlaySpeed.DecimalPlaces = 1;
            this.numericUpDownPlaySpeed.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownPlaySpeed.Location = new System.Drawing.Point(289, 730);
            this.numericUpDownPlaySpeed.Name = "numericUpDownPlaySpeed";
            this.numericUpDownPlaySpeed.Size = new System.Drawing.Size(71, 19);
            this.numericUpDownPlaySpeed.TabIndex = 65;
            this.numericUpDownPlaySpeed.Value = new decimal(new int[] {
            10,
            0,
            0,
            65536});
            this.numericUpDownPlaySpeed.Leave += new System.EventHandler(this.numericUpDownPlaySpeed_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(199, 732);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 12);
            this.label11.TabIndex = 62;
            this.label11.Text = "ログ再生スピード";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 762);
            this.Controls.Add(this.numericUpDownPlaySpeed);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.comboBoxChartingTarget2);
            this.Controls.Add(this.buttonLogClear);
            this.Controls.Add(this.comboBoxChartingTarget1);
            this.Controls.Add(this.csvOutputButton);
            this.Controls.Add(this.comboBoxChartingTarget0);
            this.Controls.Add(this.csvInportButton);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.buttonPlayerStop);
            this.Controls.Add(this.chart0);
            this.Controls.Add(this.buttonPlay);
            this.Controls.Add(this.comboBoxPort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.groupBox2);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "NxtCommunicator v2.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelCourse.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiEast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiWest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiNorth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNxtMukiSouth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPoint)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCourseScale)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabPageLog.ResumeLayout(false);
            this.tabPageLog.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownMaxLine)).EndInit();
            this.tabPageMovie.ResumeLayout(false);
            this.tabPageMovie.PerformLayout();
            this.tabPageSetting.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownTireRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownShajikuLen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPlaySpeed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.TextBox textBoxVal1;
        private System.Windows.Forms.TextBox textBoxVal2;
        private System.Windows.Forms.TextBox textBoxVal3;
        private System.Windows.Forms.TextBox textBoxVal4;
        private System.Windows.Forms.TextBox textBoxVal5;
        private System.Windows.Forms.TextBox textBoxVal6;
        private System.Windows.Forms.TextBox textBoxVal7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button val1SendButton;
        private System.Windows.Forms.Button buttonLogClear;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart0;
        private System.Windows.Forms.Button csvOutputButton;
        private System.Windows.Forms.Button csvInportButton;
        private System.Windows.Forms.Button val2SendButton;
        private System.Windows.Forms.Button val3SendButton;
        private System.Windows.Forms.Button val4SendButton;
        private System.Windows.Forms.Button val5SendButton;
        private System.Windows.Forms.Button val6SendButton;
        private System.Windows.Forms.Button val7SendButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Time;
        private System.Windows.Forms.DataGridViewTextBoxColumn b;
        private System.Windows.Forms.DataGridViewTextBoxColumn c;
        private System.Windows.Forms.DataGridViewTextBoxColumn d;
        private System.Windows.Forms.DataGridViewTextBoxColumn e;
        private System.Windows.Forms.DataGridViewTextBoxColumn f;
        private System.Windows.Forms.DataGridViewTextBoxColumn g;
        private System.Windows.Forms.DataGridViewTextBoxColumn h;
        private System.Windows.Forms.DataGridViewTextBoxColumn i;
        private System.Windows.Forms.DataGridViewTextBoxColumn j;
        private System.Windows.Forms.DataGridViewTextBoxColumn k;
        private System.Windows.Forms.DataGridViewTextBoxColumn l;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.ComboBox comboBoxChartingTarget0;
        private System.Windows.Forms.ComboBox comboBoxChartingTarget1;
        private System.Windows.Forms.ComboBox comboBoxChartingTarget2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panelCourse;
        private System.Windows.Forms.PictureBox pictureBoxPoint;
        private System.Windows.Forms.Button buttonPlay;
        private System.Windows.Forms.Button buttonPlayerStop;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxKakudo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelTireRadius;
        private System.Windows.Forms.Label labelShajiku;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageLog;
        private System.Windows.Forms.TabPage tabPageMovie;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPageSetting;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numUpDownCourseScale;
        private System.Windows.Forms.NumericUpDown numUpDownShajikuLen;
        private System.Windows.Forms.NumericUpDown numUpDownTireRadius;
        private System.Windows.Forms.PictureBox pictureBoxNxtMukiSouth;
        private System.Windows.Forms.PictureBox pictureBoxNxtMukiEast;
        private System.Windows.Forms.PictureBox pictureBoxNxtMukiWest;
        private System.Windows.Forms.PictureBox pictureBoxNxtMukiNorth;
        private System.Windows.Forms.NumericUpDown numericUpDownPlaySpeed;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numUpDownMaxLine;
    }
}

